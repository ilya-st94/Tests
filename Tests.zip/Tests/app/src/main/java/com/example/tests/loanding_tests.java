package com.example.tests;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class loanding_tests extends AppCompatActivity {


    private ArrayList<String> arrayList1;
    private ArrayList<String> arrayList2;
    private ArrayList<String> arrayList3;
    private ArrayList<String> arrayList4;
    private ArrayList<String> arrayList5;
    private ArrayList<String> arrayList6;
    private Button button;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loanding_tests);
        init();
        get_elements();
    }

    private void init(){
        button = findViewById(R.id.kjpka);
        databaseReference = FirebaseDatabase.getInstance().getReference("Tests");
        arrayList1 = new ArrayList<>();
        arrayList2 = new ArrayList<>();
        arrayList3 = new ArrayList<>();
        arrayList4 = new ArrayList<>();
        arrayList5 = new ArrayList<>();
        arrayList6 = new ArrayList<>();
    }

    private void get_elements(){
        ValueEventListener valueEventListener =new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(arrayList1.size()>0){
                    arrayList1.clear();
                }
               if(arrayList2.size()>0){
                    arrayList2.clear();
                }
                if(arrayList3.size()>0){
                    arrayList3.clear();
                }
                if(arrayList4.size()>0){
                    arrayList4.clear();
                }
                if(arrayList5.size()>0){
                    arrayList5.clear();
                }
                if(arrayList6.size()>0){
                    arrayList6.clear();
                }

                for(DataSnapshot ds : snapshot.getChildren()){
                    Tests tests = ds.getValue(Tests.class);

                    assert tests != null;
                    arrayList1.add(tests.getQuation());
                    arrayList2.add(tests.getAnswer1());
                    arrayList3.add(tests.getAnswer2());
                    arrayList4.add(tests.getAnswer3());
                    arrayList5.add(tests.getKol());
                    arrayList6.add(tests.getTime());

                }




                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                      isNetworkAvailable(loanding_tests.this);
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };
        databaseReference.addValueEventListener(valueEventListener);

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slidein_y,R.anim.slideout_y);
    }

    public void isNetworkAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            Intent intent = new Intent(loanding_tests.this, Samtest.class);
            intent.putExtra("вопрос",arrayList1);
            intent.putExtra("ответ1",arrayList2);
            intent.putExtra("ответ2",arrayList3);
            intent.putExtra("правельный_ответ",arrayList4);
            intent.putExtra("количество_вопросов",arrayList5);
            intent.putExtra("время",arrayList6);
            startActivity(intent);
            overridePendingTransition(R.anim.slidein_y,R.anim.slideout_y);
        } else {
            Toast.makeText(this, "Нету доступа к интернету", Toast.LENGTH_SHORT).show();
        }
    }

}