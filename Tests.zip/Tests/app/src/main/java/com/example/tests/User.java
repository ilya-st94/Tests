package com.example.tests;

public class User {

    private String id,number_student, first_name, second_name;

    public User(){

    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumber_student() {
        return number_student;
    }

    public void setNumber_student(String number_student) {
        this.number_student = number_student;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getSecond_name() {
        return second_name;
    }

    public void setSecond_name(String second_name) {
        this.second_name = second_name;
    }
}
