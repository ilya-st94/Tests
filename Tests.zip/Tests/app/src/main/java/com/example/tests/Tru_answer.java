package com.example.tests;

public class Tru_answer {

    private String tru_answer, id;

    public String getTru_answer() {
        return tru_answer;
    }

    public void setTru_answer(String tru_answer) {
        this.tru_answer = tru_answer;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
